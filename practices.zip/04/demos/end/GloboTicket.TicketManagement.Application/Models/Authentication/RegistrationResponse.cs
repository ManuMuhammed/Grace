﻿namespace GloboTicket.TicketManagement.Application.Models.Authentication
{
    public class RegistrationResponse
    {
        public string UserId { get; set; }
    }
}
